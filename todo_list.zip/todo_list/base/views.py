from typing import Any, Optional
from django.db import models
from django.shortcuts import render,HttpResponse,redirect,HttpResponseRedirect
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView , UpdateView , DeleteView , FormView
from django.urls import reverse_lazy
from .models import Task

from django.contrib.auth.views import LoginView , LogoutView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login

# Create your views here.

class CustomLoginView(LoginView):
    template_name = 'base/login.html'
    fields = '__all__'
    redirect_authenticated_user = True
    
    def get_success_url(self):
        return reverse_lazy('tasks')


class RegisterPage(FormView):
    template_name = 'base/register.html'
    form_class = UserCreationForm
    redirect_authenticated_user = True
    success_url = reverse_lazy('tasks')
    
    def form_valid(self ,form):
        user = form.save()
        if user is not None:
            login(self.request , user)
        return super(RegisterPage , self).form_valid(form)

    def get(self , *args , **kwargs):
        if self.request.user.is_authenticated:
            return redirect('/')
        return super(RegisterPage , self).get(*args, **kwargs)
    
# context_object_name = to change name of the context in html file
# template_name = to change name of the template(html file name)

class TaskList(LoginRequiredMixin , ListView):
    model = Task
    print(model)
    context_object_name = "tasks"
    
    def get_context_data(self , **kwargs):
        context = super().get_context_data(**kwargs)
        # print(context)
        context['tasks'] = context['tasks'].filter(user=self.request.user)
        context['count'] = context['tasks'].filter(complete=False).count()
        
        search_input =  self.request.GET.get('search-area') or ""
        if search_input:
            context['tasks'] = context['tasks'].filter(title__icontains = search_input)
            
        context['search_input'] = search_input
        # print(context)
        return context
    
    
    
class Change(DetailView):
    model = Task  
    success_url = reverse_lazy("tasks")

    
class TaskCreate(LoginRequiredMixin  , CreateView):
    model = Task
    fields = ('title', 'description', 'complete')
    success_url = reverse_lazy("tasks")
    
    def form_valid(self, form):
        form.instance.user = self.request.user
        return super(TaskCreate, self).form_valid(form)
    
class TaskUpdate(LoginRequiredMixin  , UpdateView):
    model = Task
    fields = ('title', 'description', 'complete')
    success_url = reverse_lazy("tasks")
    
class TaskDelete(LoginRequiredMixin  , DeleteView):
    model = Task
    context_object_name = "task"
    success_url = reverse_lazy("tasks")
    
    
class TaskDetail(LoginRequiredMixin  , DetailView):
    model = Task
    context_object_name = "task"
    template_name = "base/task_detail.html"
    

    
    
    
    
    